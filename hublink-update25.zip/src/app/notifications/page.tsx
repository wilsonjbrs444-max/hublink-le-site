import { redirect } from "next/navigation";
import {
  Briefcase,
  CheckCircle2,
  MessageCircle,
  UserPlus,
  Bell,
} from "lucide-react";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/currentUser";
import MarkAllReadButton from "@/components/MarkAllReadButton";

export const dynamic = "force-dynamic";

const typeIcon: Record<string, any> = {
  nouvelle_offre: Briefcase,
  offre_acceptee: CheckCircle2,
  nouveau_message: MessageCircle,
  nouvel_abonne: UserPlus,
};

export default async function NotificationsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const notifications = await prisma.notification.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <div className="mx-auto max-w-2xl px-4 py-12">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Notifications</h1>
        {unreadCount > 0 && <MarkAllReadButton />}
      </div>

      <div className="mt-8 space-y-2">
        {notifications.map((n) => {
          const Icon = typeIcon[n.type] || Bell;
          return (
            <div
              key={n.id}
              className={`flex items-start gap-3 rounded-lg border p-4 ${
                n.isRead ? "bg-white" : "bg-hublink-light"
              }`}
            >
              <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white text-hublink">
                <Icon size={16} />
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-800">{n.content}</p>
                <p className="mt-1 text-xs text-gray-400">
                  {new Date(n.createdAt).toLocaleString("fr-FR")}
                </p>
              </div>
              {!n.isRead && (
                <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-hublink" />
              )}
            </div>
          );
        })}
        {notifications.length === 0 && (
          <p className="text-sm text-gray-500">Aucune notification pour le moment.</p>
        )}
      </div>
    </div>
  );
}
