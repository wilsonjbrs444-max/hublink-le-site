import Link from "next/link";
import {
  Wrench,
  Briefcase,
  MapPin,
  ShoppingCart,
  MessageCircle,
  LayoutDashboard,
  ShieldCheck,
} from "lucide-react";
import Logo from "./Logo";
import { getCurrentUser } from "@/lib/currentUser";
import LogoutButton from "./LogoutButton";

const links = [
  { href: "/services", label: "Services", Icon: Wrench },
  { href: "/freelance", label: "Freelance", Icon: Briefcase },
  { href: "/technicians", label: "Techniciens", Icon: MapPin },
  { href: "/marketplace", label: "Marketplace", Icon: ShoppingCart },
  { href: "/messages", label: "Messages", Icon: MessageCircle },
];

export default async function Navbar() {
  const user = await getCurrentUser();

  return (
    <header className="sticky top-0 z-40 border-b bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-2.5">
        <Logo variant="icon" />

        <nav className="flex items-center gap-1">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="flex w-14 flex-col items-center gap-0.5 rounded-lg py-1.5 text-gray-500 transition hover:bg-hublink-light hover:text-hublink"
            >
              <l.Icon size={19} strokeWidth={2} />
              <span className="text-[10px] font-medium leading-none">{l.label}</span>
            </Link>
          ))}
          {user && (
            <Link
              href="/dashboard"
              className="flex w-14 flex-col items-center gap-0.5 rounded-lg py-1.5 text-gray-500 transition hover:bg-hublink-light hover:text-hublink"
            >
              <LayoutDashboard size={19} strokeWidth={2} />
              <span className="text-[10px] font-medium leading-none">Tableau</span>
            </Link>
          )}
          {user?.isAdmin && (
            <Link
              href="/admin"
              className="flex w-14 flex-col items-center gap-0.5 rounded-lg py-1.5 text-purple-600 transition hover:bg-purple-50"
            >
              <ShieldCheck size={19} strokeWidth={2} />
              <span className="text-[10px] font-medium leading-none">Admin</span>
            </Link>
          )}
        </nav>

        <div className="flex items-center gap-2 text-sm">
          {user ? (
            <>
              <Link
                href={`/profile/${user.id}`}
                className="hidden items-center gap-2 rounded-full py-1 pl-1 pr-3 text-gray-600 hover:bg-gray-50 sm:flex"
              >
                <span className="flex h-7 w-7 items-center justify-center overflow-hidden rounded-full bg-hublink-light text-xs font-semibold text-hublink">
                  {user.avatarUrl ? (
                    <img src={user.avatarUrl} alt="" className="h-full w-full object-cover" />
                  ) : (
                    user.fullName.charAt(0).toUpperCase()
                  )}
                </span>
                {user.fullName.split(" ")[0]}
              </Link>
              <LogoutButton />
            </>
          ) : (
            <>
              <Link
                href="/login"
                className="rounded-md px-3 py-2 font-medium text-gray-700 hover:bg-gray-100"
              >
                Connexion
              </Link>
              <Link
                href="/register"
                className="rounded-md bg-hublink px-3 py-2 font-medium text-white hover:bg-hublink-dark"
              >
                Inscription
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
