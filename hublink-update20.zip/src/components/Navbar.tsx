import Link from "next/link";
import { getCurrentUser } from "@/lib/currentUser";
import LogoutButton from "./LogoutButton";

const links = [
  { href: "/services", label: "Services" },
  { href: "/freelance", label: "Freelance" },
  { href: "/technicians", label: "Techniciens" },
  { href: "/marketplace", label: "Marketplace" },
  { href: "/messages", label: "Messages" },
  { href: "/dashboard", label: "Tableau de bord" },
];

export default async function Navbar() {
  const user = await getCurrentUser();

  return (
    <header className="border-b bg-white">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
        <Link href="/" className="text-xl font-bold text-hublink">
          HUBLINK
        </Link>
        <nav className="hidden gap-6 text-sm font-medium text-gray-600 md:flex">
          {links.map((l) => (
            <Link key={l.href} href={l.href} className="hover:text-hublink">
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-3 text-sm">
          {user ? (
            <>
              {user.isAdmin && (
                <Link
                  href="/admin"
                  className="rounded-md bg-purple-100 px-3 py-2 font-medium text-purple-700 hover:bg-purple-200"
                >
                  Admin
                </Link>
              )}
              <span className="hidden text-gray-600 sm:inline">
                Bonjour, {user.fullName.split(" ")[0]}
              </span>
              <LogoutButton />
            </>
          ) : (
            <>
              <Link
                href="/login"
                className="rounded-md px-3 py-2 font-medium text-gray-700 hover:bg-gray-100"
              >
                Connexion
              </Link>
              <Link
                href="/register"
                className="rounded-md bg-hublink px-3 py-2 font-medium text-white hover:bg-hublink-dark"
              >
                Inscription
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
