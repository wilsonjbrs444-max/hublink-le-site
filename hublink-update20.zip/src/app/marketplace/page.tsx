import Link from "next/link";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function MarketplacePage() {
  const products = await prisma.product.findMany({
    where: { isActive: true },
    orderBy: { createdAt: "desc" },
    include: { seller: true },
  });

  return (
    <div className="mx-auto max-w-6xl px-4 py-12">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Marketplace</h1>
          <p className="mt-1 text-sm text-gray-600">
            Matériel informatique vendu par nos vendeurs vérifiés.
          </p>
        </div>
        <Link
          href="/marketplace/create"
          className="rounded-md bg-hublink px-4 py-2 text-sm font-semibold text-white hover:bg-hublink-dark"
        >
          + Vendre un produit
        </Link>
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {products.map((p) => {
          const images: string[] = p.images ? JSON.parse(p.images) : [];
          return (
            <div
              key={p.id}
              className="overflow-hidden rounded-lg border bg-white shadow-sm"
            >
              <Link href={`/marketplace/${p.id}`} className="block">
                <div className="flex aspect-video items-center justify-center bg-gray-100 text-4xl">
                  {images[0] ? (
                    <img
                      src={images[0]}
                      alt={p.name}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    "🖥"
                  )}
                </div>
                <div className="px-4 pt-4">
                  <h3 className="font-semibold text-gray-900">{p.name}</h3>
                </div>
              </Link>
              <div className="px-4 pb-4">
                <Link
                  href={`/profile/${p.seller.userId}`}
                  className="mt-1 block text-xs text-hublink hover:underline"
                >
                  Vendu par {p.seller.shopName}
                </Link>
                <p className="mt-2 font-semibold text-hublink">
                  {Number(p.price).toLocaleString("fr-FR")} FCFA
                </p>
              </div>
            </div>
          );
        })}
        {products.length === 0 && (
          <p className="text-sm text-gray-500">
            Aucun produit en vente pour le moment. Les vendeurs peuvent en
            ajouter depuis leur tableau de bord.
          </p>
        )}
      </div>
    </div>
  );
}
