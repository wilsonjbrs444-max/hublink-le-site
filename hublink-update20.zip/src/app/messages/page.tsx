import Link from "next/link";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/currentUser";

export const dynamic = "force-dynamic";

export default async function MessagesInboxPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const conversations = await prisma.conversation.findMany({
    where: { participants: { some: { userId: user.id } } },
    include: {
      participants: { include: { user: true } },
      messages: { orderBy: { createdAt: "desc" }, take: 1 },
    },
  });

  // Trie par date du dernier message (plus récent en premier)
  const sorted = conversations
    .filter((c) => c.messages.length > 0)
    .sort(
      (a, b) =>
        new Date(b.messages[0].createdAt).getTime() -
        new Date(a.messages[0].createdAt).getTime()
    );

  return (
    <div className="mx-auto max-w-2xl px-4 py-12">
      <h1 className="text-2xl font-bold">Messages</h1>
      <p className="mt-1 text-sm text-gray-600">
        Toutes tes conversations, peu importe d'où elles ont démarré.
      </p>

      <div className="mt-8 space-y-2">
        {sorted.map((c) => {
          const other = c.participants.find((p) => p.userId !== user.id)?.user;
          const lastMessage = c.messages[0];
          if (!other) return null;
          return (
            <Link
              key={c.id}
              href={`/messages/${c.id}`}
              className="flex items-center gap-3 rounded-lg border bg-white p-4 hover:shadow-sm"
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-hublink-light text-sm font-semibold text-hublink">
                {other.fullName.charAt(0).toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <p className="font-medium text-gray-900">{other.fullName}</p>
                <p className="truncate text-sm text-gray-500">
                  {lastMessage.senderId === user.id ? "Toi : " : ""}
                  {lastMessage.content}
                </p>
              </div>
              <span className="shrink-0 text-xs text-gray-400">
                {new Date(lastMessage.createdAt).toLocaleDateString("fr-FR")}
              </span>
            </Link>
          );
        })}
        {sorted.length === 0 && (
          <p className="text-sm text-gray-500">
            Aucun message pour le moment. Écris à un vendeur ou un technicien
            pour démarrer une conversation.
          </p>
        )}
      </div>
    </div>
  );
}
