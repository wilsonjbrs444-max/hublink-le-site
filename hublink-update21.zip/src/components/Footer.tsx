import Link from "next/link";
import Logo from "./Logo";

export default function Footer() {
  return (
    <footer className="border-t bg-white py-8 text-sm text-gray-500">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 sm:flex-row">
        <div className="flex items-center gap-3">
          <Logo variant="icon" />
          <span className="text-xs text-gray-400">
            © {new Date().getFullYear()} Tous droits réservés.
          </span>
        </div>
        <div className="flex gap-4">
          <Link href="/training" className="hover:text-hublink">
            Formation
          </Link>
          <Link href="/quotes" className="hover:text-hublink">
            Devis Pro
          </Link>
          <Link href="/blog" className="hover:text-hublink">
            Blog
          </Link>
          <Link href="/support" className="hover:text-hublink">
            Assistance
          </Link>
        </div>
      </div>
    </footer>
  );
}
