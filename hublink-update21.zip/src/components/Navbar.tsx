import Link from "next/link";
import Logo from "./Logo";
import { getCurrentUser } from "@/lib/currentUser";
import LogoutButton from "./LogoutButton";

const links = [
  { href: "/services", label: "Services", icon: "🧰" },
  { href: "/freelance", label: "Freelance", icon: "💼" },
  { href: "/technicians", label: "Techniciens", icon: "📍" },
  { href: "/marketplace", label: "Marketplace", icon: "🛒" },
  { href: "/messages", label: "Messages", icon: "💬" },
];

export default async function Navbar() {
  const user = await getCurrentUser();

  return (
    <header className="sticky top-0 z-40 border-b bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Logo variant="icon" />

        <nav className="flex items-center gap-1">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              title={l.label}
              aria-label={l.label}
              className="flex h-10 w-10 items-center justify-center rounded-lg text-lg text-gray-500 transition hover:bg-hublink-light hover:text-hublink"
            >
              {l.icon}
            </Link>
          ))}
          {user && (
            <Link
              href="/dashboard"
              title="Tableau de bord"
              aria-label="Tableau de bord"
              className="flex h-10 w-10 items-center justify-center rounded-lg text-lg text-gray-500 transition hover:bg-hublink-light hover:text-hublink"
            >
              📊
            </Link>
          )}
          {user?.isAdmin && (
            <Link
              href="/admin"
              title="Panel Admin"
              aria-label="Panel Admin"
              className="flex h-10 w-10 items-center justify-center rounded-lg text-lg text-purple-600 transition hover:bg-purple-50"
            >
              🛡
            </Link>
          )}
        </nav>

        <div className="flex items-center gap-2 text-sm">
          {user ? (
            <>
              <Link
                href={`/profile/${user.id}`}
                className="hidden items-center gap-2 rounded-full py-1 pl-1 pr-3 text-gray-600 hover:bg-gray-50 sm:flex"
              >
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-hublink-light text-xs font-semibold text-hublink">
                  {user.fullName.charAt(0).toUpperCase()}
                </span>
                {user.fullName.split(" ")[0]}
              </Link>
              <LogoutButton />
            </>
          ) : (
            <>
              <Link
                href="/login"
                className="rounded-md px-3 py-2 font-medium text-gray-700 hover:bg-gray-100"
              >
                Connexion
              </Link>
              <Link
                href="/register"
                className="rounded-md bg-hublink px-3 py-2 font-medium text-white hover:bg-hublink-dark"
              >
                Inscription
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
