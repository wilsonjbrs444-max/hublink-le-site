type Props = {
  variant?: "light" | "dark"; // light = texte blanc (fond sombre), dark = texte coloré (fond clair)
  size?: "sm" | "md" | "lg";
  showTagline?: boolean;
};

const sizes = {
  sm: { icon: 28, text: "text-lg", tagline: "text-[10px]" },
  md: { icon: 36, text: "text-xl", tagline: "text-xs" },
  lg: { icon: 48, text: "text-2xl", tagline: "text-sm" },
};

export default function Logo({
  variant = "dark",
  size = "md",
  showTagline = true,
}: Props) {
  const s = sizes[size];
  const textColor = variant === "light" ? "text-white" : "text-gray-900";
  const taglineColor = variant === "light" ? "text-slate-400" : "text-gray-500";

  return (
    <div className="flex items-center gap-2.5">
      <svg
        width={s.icon}
        height={s.icon}
        viewBox="0 0 40 40"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0"
      >
        <defs>
          <linearGradient id="hublinkGrad" x1="0" y1="0" x2="40" y2="40">
            <stop offset="0%" stopColor="#2563EB" />
            <stop offset="100%" stopColor="#22C55E" />
          </linearGradient>
        </defs>
        <rect width="40" height="40" rx="11" fill="url(#hublinkGrad)" />
        {/* Symbole de lien : deux anneaux entrelacés */}
        <path
          d="M15 24a5 5 0 0 1 0-8h3"
          stroke="white"
          strokeWidth="2.6"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M25 16a5 5 0 0 1 0 8h-3"
          stroke="white"
          strokeWidth="2.6"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M16.5 20h7"
          stroke="white"
          strokeWidth="2.6"
          strokeLinecap="round"
        />
      </svg>
      <div className="leading-tight">
        <div className={`font-extrabold tracking-tight ${s.text} ${textColor}`}>
          HUB<span className="text-green-500">LINK</span>
        </div>
        {showTagline && (
          <div className={`${s.tagline} ${taglineColor} font-medium tracking-wide`}>
            Le lien de l'innovation
          </div>
        )}
      </div>
    </div>
  );
}
