import type { Metadata } from "next";
import "./globals.css";
import Sidebar from "@/components/Sidebar";
import MobileTopBar from "@/components/MobileTopBar";
import BottomNav from "@/components/BottomNav";

export const metadata: Metadata = {
  title: "HUBLINK — Le lien de l'innovation",
  description:
    "HUBLINK connecte particuliers, entreprises, techniciens et vendeurs autour des services informatiques.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr">
      <body className="bg-gray-50">
        <Sidebar />
        <div className="lg:pl-64">
          <MobileTopBar />
          <main className="pb-20 lg:pb-0">{children}</main>
          <footer className="hidden border-t bg-white px-6 py-4 text-xs text-gray-400 lg:block">
            © {new Date().getFullYear()} HUBLINK — Tous droits réservés.
          </footer>
        </div>
        <BottomNav />
      </body>
    </html>
  );
}
