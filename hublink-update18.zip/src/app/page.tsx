import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/currentUser";
import { DEFAULT_SERVICES } from "@/lib/seedServices";

export const dynamic = "force-dynamic";

const urgencyBadge: Record<string, { label: string; className: string }> = {
  aujourd_hui: { label: "Aujourd'hui", className: "bg-red-100 text-red-700" },
  cette_semaine: { label: "Cette semaine", className: "bg-orange-100 text-orange-700" },
  flexible: { label: "Flexible", className: "bg-green-100 text-green-700" },
};

export default async function HomePage() {
  const user = await getCurrentUser();

  const [
    usersCount,
    missionsCount,
    productsCount,
    technicians,
    recentMissions,
    featuredProducts,
  ] = await Promise.all([
    prisma.user.count(),
    prisma.mission.count(),
    prisma.product.count(),
    prisma.freelanceProfile.findMany({
      include: { user: true },
      orderBy: { ratingAvg: "desc" },
      take: 3,
    }),
    prisma.mission.findMany({
      orderBy: { createdAt: "desc" },
      take: 4,
      include: { _count: { select: { offers: true } } },
    }),
    prisma.product.findMany({
      where: { isActive: true },
      orderBy: { createdAt: "desc" },
      take: 4,
      include: { seller: true },
    }),
  ]);

  const stats = [
    { value: `${technicians.length > 0 ? "500+" : "0"}`, label: "Techniciens certifiés" },
    { value: `${missionsCount}`, label: "Missions publiées" },
    { value: `${productsCount}`, label: "Produits en vente" },
    { value: `${usersCount}`, label: "Membres HUBLINK" },
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 lg:px-8 lg:py-8">
      {/* Zone recherche desktop */}
      <div className="mb-6 hidden items-center gap-3 lg:flex">
        <div className="flex flex-1 items-center gap-2 rounded-xl border bg-white px-4 py-3 shadow-sm">
          <span>🔍</span>
          <input
            placeholder="Rechercher un service, un technicien, un produit..."
            className="w-full text-sm outline-none"
          />
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Colonne principale */}
        <div className="space-y-6 lg:col-span-2">
          {/* Hero */}
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#0B1230] via-[#0F1B4D] to-[#0B3B2E] p-8 text-white">
            <div className="relative z-10 max-w-md">
              <p className="text-sm font-medium text-blue-300">
                Bienvenue sur HUBLINK
              </p>
              <h1 className="mt-2 text-3xl font-extrabold leading-tight">
                La plateforme tout-en-un pour vos besoins numériques
              </h1>
              <div className="mt-6 flex flex-wrap gap-3">
                <Link
                  href="/services"
                  className="rounded-lg bg-green-500 px-5 py-2.5 text-sm font-semibold hover:bg-green-600"
                >
                  Découvrir nos services
                </Link>
                <Link
                  href="/freelance/create"
                  className="rounded-lg bg-white/10 px-5 py-2.5 text-sm font-semibold backdrop-blur hover:bg-white/20"
                >
                  Publier une mission
                </Link>
              </div>
            </div>
            <div className="pointer-events-none absolute -right-10 -top-10 h-56 w-56 rounded-full bg-green-500/20 blur-3xl" />
            <div className="pointer-events-none absolute -bottom-10 right-16 h-40 w-40 rounded-full bg-blue-500/20 blur-3xl" />
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {stats.map((s) => (
              <div key={s.label} className="rounded-xl border bg-white p-4 text-center shadow-sm">
                <p className="text-xl font-extrabold text-gray-900">{s.value}</p>
                <p className="mt-1 text-xs text-gray-500">{s.label}</p>
              </div>
            ))}
          </div>

          {/* Catégories de services */}
          <div>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-bold text-gray-900">Nos services</h2>
              <Link href="/services" className="text-sm font-medium text-hublink">
                Voir tous les services →
              </Link>
            </div>
            <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">
              {DEFAULT_SERVICES.slice(0, 6).map((s) => (
                <Link
                  key={s.slug}
                  href={`/services/${s.slug}`}
                  className="flex flex-col items-center gap-2 rounded-xl border bg-white p-3 text-center shadow-sm hover:shadow-md"
                >
                  <span className="text-2xl">{s.icon}</span>
                  <span className="text-xs font-medium text-gray-700">{s.title}</span>
                </Link>
              ))}
            </div>
          </div>

          {/* Missions récentes */}
          <div>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-bold text-gray-900">Missions récentes</h2>
              <Link href="/freelance" className="text-sm font-medium text-hublink">
                Voir toutes →
              </Link>
            </div>
            <div className="space-y-2">
              {recentMissions.map((m) => {
                const badge = urgencyBadge[m.urgency] || urgencyBadge.flexible;
                return (
                  <Link
                    key={m.id}
                    href={`/freelance/${m.id}`}
                    className="flex items-center justify-between rounded-xl border bg-white p-4 shadow-sm hover:shadow-md"
                  >
                    <div>
                      <p className="font-medium text-gray-900">{m.title}</p>
                      <p className="text-xs text-gray-500">
                        📍 {m.city || "Non précisé"} · {m._count.offers} offre(s)
                      </p>
                    </div>
                    <span className={`rounded-full px-2 py-1 text-xs font-medium ${badge.className}`}>
                      {badge.label}
                    </span>
                  </Link>
                );
              })}
              {recentMissions.length === 0 && (
                <p className="text-sm text-gray-500">Aucune mission pour le moment.</p>
              )}
            </div>
          </div>

          {/* Marketplace en vedette */}
          <div>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-bold text-gray-900">Marketplace en vedette</h2>
              <Link href="/marketplace" className="text-sm font-medium text-hublink">
                Voir tout →
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {featuredProducts.map((p) => {
                const images: string[] = p.images ? JSON.parse(p.images) : [];
                return (
                  <div key={p.id} className="overflow-hidden rounded-xl border bg-white shadow-sm">
                    <div className="flex aspect-square items-center justify-center bg-gray-100 text-3xl">
                      {images[0] ? (
                        <img src={images[0]} alt={p.name} className="h-full w-full object-cover" />
                      ) : (
                        "🖥"
                      )}
                    </div>
                    <div className="p-3">
                      <p className="truncate text-xs font-medium text-gray-900">{p.name}</p>
                      <p className="mt-1 text-xs font-semibold text-hublink">
                        {Number(p.price).toLocaleString("fr-FR")} FCFA
                      </p>
                    </div>
                  </div>
                );
              })}
              {featuredProducts.length === 0 && (
                <p className="col-span-full text-sm text-gray-500">
                  Aucun produit pour le moment.
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Colonne latérale (desktop) */}
        <div className="hidden space-y-6 lg:block">
          <div className="rounded-xl border bg-white p-5 shadow-sm">
            <h3 className="font-semibold text-gray-900">Trouver un technicien</h3>
            <p className="mt-1 text-xs text-gray-500">
              Trouvez rapidement un professionnel près de chez vous.
            </p>
            <Link
              href="/technicians"
              className="mt-3 block rounded-lg bg-hublink py-2.5 text-center text-sm font-semibold text-white hover:bg-hublink-dark"
            >
              Rechercher
            </Link>

            <div className="mt-4 space-y-3">
              {technicians.map((t) => (
                <Link
                  key={t.id}
                  href="/technicians"
                  className="flex items-center gap-3 rounded-lg p-2 hover:bg-gray-50"
                >
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-hublink-light text-sm font-semibold text-hublink">
                    {t.user.fullName.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">
                      {t.user.fullName}
                    </p>
                    <p className="text-xs text-gray-500">
                      ⭐ {Number(t.ratingAvg).toFixed(1)}
                    </p>
                  </div>
                </Link>
              ))}
              {technicians.length === 0 && (
                <p className="text-xs text-gray-500">Aucun technicien pour le moment.</p>
              )}
            </div>
          </div>

          <div className="rounded-xl bg-gradient-to-br from-blue-600 to-green-500 p-5 text-white shadow-sm">
            <h3 className="font-semibold">Publier une mission</h3>
            <p className="mt-1 text-xs text-blue-50">
              Décrivez votre besoin et recevez des propositions.
            </p>
            <Link
              href="/freelance/create"
              className="mt-3 block rounded-lg bg-white py-2.5 text-center text-sm font-semibold text-blue-700 hover:bg-blue-50"
            >
              Publier maintenant
            </Link>
          </div>
        </div>
      </div>

      {/* Bandeau confiance */}
      <div className="mt-8 grid grid-cols-2 gap-3 rounded-xl bg-[#0B1230] p-5 text-white sm:grid-cols-4">
        {[
          { icon: "🔒", label: "Paiement sécurisé" },
          { icon: "🔄", label: "Support 24/7" },
          { icon: "✅", label: "Qualité garantie" },
          { icon: "🛡", label: "Techniciens vérifiés" },
        ].map((f) => (
          <div key={f.label} className="flex items-center gap-2 text-xs">
            <span className="text-lg">{f.icon}</span>
            {f.label}
          </div>
        ))}
      </div>
    </div>
  );
}
