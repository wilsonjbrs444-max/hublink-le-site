import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/currentUser";
import FollowButton from "@/components/FollowButton";
import { MapPin, BadgeCheck, Star, Monitor } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function ProfilePage({
  params,
}: {
  params: { id: string };
}) {
  const profileUser = await prisma.user.findUnique({
    where: { id: params.id },
    include: {
      freelanceProfile: true,
      sellerProfile: { include: { products: { where: { isActive: true } } } },
      missionsPosted: { orderBy: { createdAt: "desc" }, take: 10 },
      _count: { select: { followers: true, following: true } },
    },
  });

  if (!profileUser) notFound();

  const currentUser = await getCurrentUser();
  const isOwnProfile = currentUser?.id === profileUser.id;

  const isFollowing = currentUser
    ? !!(await prisma.follow.findUnique({
        where: {
          followerId_followingId: {
            followerId: currentUser.id,
            followingId: profileUser.id,
          },
        },
      }))
    : false;

  const skills: string[] = profileUser.freelanceProfile?.skills
    ? JSON.parse(profileUser.freelanceProfile.skills)
    : [];

  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      {/* En-tête profil */}
      <div className="rounded-lg border bg-white p-6">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-hublink-light text-2xl font-semibold text-hublink">
              {profileUser.fullName.charAt(0).toUpperCase()}
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">
                {profileUser.fullName}
                {profileUser.freelanceProfile?.certificationStatus === "certifie" && (
                  <span className="ml-2 inline-flex items-center gap-1 rounded-full bg-blue-100 px-2 py-0.5 text-xs font-medium text-blue-700">
                    <BadgeCheck size={13} /> Certifié
                  </span>
                )}
              </h1>
              <p className="flex items-center gap-1 text-sm text-gray-500">
                <MapPin size={13} /> {profileUser.city || "Ville non précisée"}
              </p>
              <p className="mt-1 text-sm text-gray-600">
                <span className="font-semibold">{profileUser._count.followers}</span> abonnés ·{" "}
                <span className="font-semibold">{profileUser._count.following}</span> abonnements
              </p>
            </div>
          </div>

          {!isOwnProfile && currentUser && (
            <FollowButton
              targetUserId={profileUser.id}
              initialFollowing={isFollowing}
            />
          )}
          {!currentUser && (
            <Link
              href="/login"
              className="rounded-md bg-hublink px-4 py-2 text-sm font-semibold text-white hover:bg-hublink-dark"
            >
              + S'abonner
            </Link>
          )}
        </div>

        {profileUser.freelanceProfile?.bio && (
          <p className="mt-4 text-sm text-gray-700">
            {profileUser.freelanceProfile.bio}
          </p>
        )}
      </div>

      {/* Service freelance */}
      {profileUser.freelanceProfile && (
        <section className="mt-6">
          <h2 className="font-semibold text-gray-900">Technicien / Freelance</h2>
          <div className="mt-3 rounded-lg border bg-white p-5">
            <div className="flex flex-wrap gap-2">
              {skills.map((s) => (
                <span
                  key={s}
                  className="rounded-full bg-gray-100 px-2 py-1 text-xs text-gray-600"
                >
                  {s}
                </span>
              ))}
              {skills.length === 0 && (
                <span className="text-xs text-gray-400">
                  Aucune compétence renseignée
                </span>
              )}
            </div>
            <div className="mt-3 flex items-center justify-between text-sm">
              <span className="flex items-center gap-1 text-gray-500">
                <Star size={14} className="fill-amber-400 text-amber-400" />
                {Number(profileUser.freelanceProfile.ratingAvg).toFixed(1)} (
                {profileUser.freelanceProfile.ratingCount}) ·{" "}
                {profileUser.freelanceProfile.yearsExperience || 0} ans d'expérience
              </span>
              {profileUser.freelanceProfile.hourlyRate && (
                <span className="font-semibold text-hublink">
                  {Number(profileUser.freelanceProfile.hourlyRate).toLocaleString("fr-FR")} FCFA/h
                </span>
              )}
            </div>
          </div>
        </section>
      )}

      {/* Produits en vente */}
      {profileUser.sellerProfile && profileUser.sellerProfile.products.length > 0 && (
        <section className="mt-6">
          <h2 className="font-semibold text-gray-900">
            Produits en vente ({profileUser.sellerProfile.products.length})
          </h2>
          <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {profileUser.sellerProfile.products.map((p) => {
              const images: string[] = p.images ? JSON.parse(p.images) : [];
              return (
                <div key={p.id} className="overflow-hidden rounded-lg border bg-white">
                  <div className="flex aspect-square items-center justify-center bg-gray-100">
                    {images[0] ? (
                      <img src={images[0]} alt={p.name} className="h-full w-full object-cover" />
                    ) : (
                      <Monitor size={24} className="text-gray-300" />
                    )}
                  </div>
                  <div className="p-2">
                    <p className="truncate text-xs font-medium">{p.name}</p>
                    <p className="text-xs font-semibold text-hublink">
                      {Number(p.price).toLocaleString("fr-FR")} FCFA
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Missions publiées */}
      {profileUser.missionsPosted.length > 0 && (
        <section className="mt-6">
          <h2 className="font-semibold text-gray-900">
            Missions publiées ({profileUser.missionsPosted.length})
          </h2>
          <div className="mt-3 space-y-2">
            {profileUser.missionsPosted.map((m) => (
              <Link
                key={m.id}
                href={`/freelance/${m.id}`}
                className="block rounded-lg border bg-white p-4 hover:shadow-sm"
              >
                <p className="font-medium">{m.title}</p>
                <p className="text-xs text-gray-500">Statut : {m.status}</p>
              </Link>
            ))}
          </div>
        </section>
      )}

      {!profileUser.freelanceProfile &&
        !profileUser.sellerProfile &&
        profileUser.missionsPosted.length === 0 && (
          <p className="mt-6 text-sm text-gray-500">
            Ce membre n'a pas encore d'activité publique sur HUBLINK.
          </p>
        )}
    </div>
  );
}
