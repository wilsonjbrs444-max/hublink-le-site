import Link from "next/link";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/currentUser";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const myMissions = await prisma.mission.findMany({
    where: { clientId: user.id },
    orderBy: { createdAt: "desc" },
    include: { _count: { select: { offers: true } } },
  });

  const myOffers = user.freelanceProfile
    ? await prisma.missionOffer.findMany({
        where: { freelanceId: user.freelanceProfile.id },
        orderBy: { createdAt: "desc" },
        include: { mission: true },
      })
    : [];

  return (
    <div className="mx-auto max-w-4xl px-4 py-12">
      <h1 className="text-2xl font-bold">Bonjour {user.fullName} 👋</h1>
      <p className="mt-1 text-sm text-gray-600">
        {user.freelanceProfile
          ? "Compte freelance actif"
          : "Compte client"}
      </p>

      {/* Missions publiées par cet utilisateur (côté client) */}
      <section className="mt-8">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold text-gray-900">
            Mes missions publiées ({myMissions.length})
          </h2>
          <Link
            href="/freelance/create"
            className="text-sm font-medium text-hublink hover:underline"
          >
            + Nouvelle mission
          </Link>
        </div>
        <div className="mt-3 space-y-2">
          {myMissions.map((m) => (
            <Link
              key={m.id}
              href={`/freelance/${m.id}`}
              className="flex items-center justify-between rounded-lg border bg-white p-4 hover:shadow-sm"
            >
              <div>
                <p className="font-medium">{m.title}</p>
                <p className="text-xs text-gray-500">
                  Statut : {m.status} · {m._count.offers} offre(s)
                </p>
              </div>
              <span className="text-sm text-gray-400">→</span>
            </Link>
          ))}
          {myMissions.length === 0 && (
            <p className="text-sm text-gray-500">
              Tu n'as encore publié aucune mission.
            </p>
          )}
        </div>
      </section>

      {/* Offres envoyées par cet utilisateur (côté freelance) */}
      {user.freelanceProfile && (
        <section className="mt-10">
          <h2 className="font-semibold text-gray-900">
            Mes offres envoyées ({myOffers.length})
          </h2>
          <div className="mt-3 space-y-2">
            {myOffers.map((o) => (
              <Link
                key={o.id}
                href={`/freelance/${o.missionId}`}
                className="flex items-center justify-between rounded-lg border bg-white p-4 hover:shadow-sm"
              >
                <div>
                  <p className="font-medium">{o.mission.title}</p>
                  <p className="text-xs text-gray-500">
                    Ton offre : {Number(o.price).toLocaleString("fr-FR")} FCFA ·{" "}
                    Statut : {o.status}
                  </p>
                </div>
                <span className="text-sm text-gray-400">→</span>
              </Link>
            ))}
            {myOffers.length === 0 && (
              <p className="text-sm text-gray-500">
                Tu n'as encore envoyé aucune offre.{" "}
                <Link href="/freelance" className="text-hublink underline">
                  Voir les missions ouvertes
                </Link>
              </p>
            )}
          </div>
        </section>
      )}
    </div>
  );
}
