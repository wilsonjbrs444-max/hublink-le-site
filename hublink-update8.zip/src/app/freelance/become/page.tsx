"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function BecomeFreelancePage() {
  const router = useRouter();
  const [form, setForm] = useState({
    bio: "",
    skillsInput: "",
    yearsExperience: "",
    hourlyRate: "",
    city: "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      // 1. Active le rôle freelance (crée le profil vide si besoin)
      const activateRes = await fetch("/api/roles/activate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role: "freelance" }),
      });
      if (!activateRes.ok) {
        const d = await activateRes.json();
        throw new Error(d.error || "Connecte-toi d'abord pour devenir freelance.");
      }

      // 2. Complète le profil avec les infos du formulaire
      const skills = form.skillsInput
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);

      const res = await fetch("/api/freelance/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          bio: form.bio,
          skills,
          yearsExperience: form.yearsExperience,
          hourlyRate: form.hourlyRate,
          city: form.city,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erreur lors de la mise à jour");

      router.push("/dashboard");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-md px-4 py-12">
      <h1 className="text-2xl font-bold">Devenir freelance HUBLINK</h1>
      <p className="mt-1 text-sm text-gray-600">
        Complète ton profil pour commencer à recevoir et faire des offres sur les missions.
      </p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-4">
        <div>
          <label className="block text-sm font-medium">Bio</label>
          <textarea
            rows={3}
            placeholder="Technicien en réseaux et maintenance PC depuis 3 ans..."
            className="mt-1 w-full rounded-md border px-3 py-2"
            value={form.bio}
            onChange={(e) => setForm({ ...form, bio: e.target.value })}
          />
        </div>
        <div>
          <label className="block text-sm font-medium">
            Compétences (séparées par des virgules)
          </label>
          <input
            placeholder="Réseaux, Maintenance PC, Installation Windows"
            className="mt-1 w-full rounded-md border px-3 py-2"
            value={form.skillsInput}
            onChange={(e) => setForm({ ...form, skillsInput: e.target.value })}
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium">Années d'expérience</label>
            <input
              type="number"
              className="mt-1 w-full rounded-md border px-3 py-2"
              value={form.yearsExperience}
              onChange={(e) => setForm({ ...form, yearsExperience: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm font-medium">Tarif horaire (FCFA)</label>
            <input
              type="number"
              className="mt-1 w-full rounded-md border px-3 py-2"
              value={form.hourlyRate}
              onChange={(e) => setForm({ ...form, hourlyRate: e.target.value })}
            />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium">Ville</label>
          <input
            placeholder="Douala"
            className="mt-1 w-full rounded-md border px-3 py-2"
            value={form.city}
            onChange={(e) => setForm({ ...form, city: e.target.value })}
          />
        </div>

        {error && <p className="text-sm text-red-600">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-md bg-hublink py-3 font-semibold text-white hover:bg-hublink-dark disabled:opacity-50"
        >
          {loading ? "Activation..." : "Activer mon profil freelance"}
        </button>
      </form>
    </div>
  );
}
