import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/currentUser";

export async function PATCH(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Non connecté." }, { status: 401 });
    }

    const { bio, skills, yearsExperience, hourlyRate, city } = await req.json();

    const profile = await prisma.freelanceProfile.update({
      where: { userId: user.id },
      data: {
        bio,
        skills: JSON.stringify(skills || []),
        yearsExperience: yearsExperience ? Number(yearsExperience) : null,
        hourlyRate: hourlyRate ? Number(hourlyRate) : null,
        city,
      },
    });

    return NextResponse.json({ profile });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { error: "Erreur serveur lors de la mise à jour du profil." },
      { status: 500 }
    );
  }
}
