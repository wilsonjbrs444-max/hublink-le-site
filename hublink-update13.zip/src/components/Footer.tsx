import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t bg-white py-8 text-sm text-gray-500">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-4 sm:flex-row">
        <p>© {new Date().getFullYear()} HUBLINK. Tous droits réservés.</p>
        <div className="flex gap-4">
          <Link href="/blog" className="hover:text-hublink">
            Blog
          </Link>
          <Link href="/support" className="hover:text-hublink">
            Assistance
          </Link>
        </div>
      </div>
    </footer>
  );
}
